import {createSlice} from "@reduxjs/toolkit"

const initialState={
     token:null
}

const authSlicer=createSlice({
    name:"authUser",
    initialState,
    reducers:{
        authUser(state:any,action){
            state.token=action.payload;
        }
    }
})
export  const {authUser}=authSlicer.actions; 
export default authSlicer.reducer;