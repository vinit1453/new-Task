import { configureStore } from "@reduxjs/toolkit";
import { authUser } from "../Slicers/auth";
export default configureStore({
    reducer:{
        store:authUser
    }
})