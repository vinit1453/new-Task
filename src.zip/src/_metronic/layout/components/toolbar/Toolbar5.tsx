import React, {FC} from 'react'

const Toolbar5: FC = () => {
  return <>Toolbar 5</>
}

export {Toolbar5}
