export interface UserCommunicationModel {
  email: boolean
  sms: boolean
  phone: boolean
}
