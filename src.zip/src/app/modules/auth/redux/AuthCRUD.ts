import axios from 'axios'
import {AuthModel} from '../models/AuthModel'
import {UserModel} from '../models/UserModel'
import {toAbsoluteUrl} from '../../../../_metronic/helpers'
const API_URL = process.env.REACT_APP_API_URL || 'api'

export const GET_USER_BY_ACCESSTOKEN_URL = `${API_URL}/auth/get-user`
export const LOGIN_URL = `${API_URL}/auth/login`
export const REGISTER_URL = `${API_URL}/auth/register`
export const REQUEST_PASSWORD_URL = `${API_URL}/auth/forgot-password`

// Server should return AuthModel
export function login(userEmail:string,userPassword:string) {
  return axios.post(LOGIN_URL, {userEmail,userPassword})
}

// Server should return AuthModel
export function register(email: string, firstname: string, lastname: string, password: string,dob:string) {
  return axios.post<AuthModel>(REGISTER_URL, {
    email,
    firstname,
    lastname,
    password,
    dob,
  })
}

// Server should return object => { result: boolean } (Is Email in DB)
export function requestPassword(email: string) {
  return axios.post<{result: boolean}>(REQUEST_PASSWORD_URL, {email})
}

export function getUserByToken() {
  // Authorization head should be fulfilled in interceptor.
  // Check common redux folder => setupAxios
  const user={data:{
    id: 1,
    username: 'admin',
    password: 'demo',
    email: 'admin@demo.com',
    auth: {
      accessToken: 'access-token-8f3ae836da744329a6f93bf20594b5cc',
      refreshToken: 'access-token-f8c137a2c98743f48b643e71161d90aa',
    },
    roles: [1], // Administrator
    pic: toAbsoluteUrl('/media/avatars/150-2.jpg'),
    fullname: 'Sean S',
    firstname: 'Sean',
    lastname: 'Stark',
    occupation: 'CEO',
    companyName: 'Keenthemes',
    phone: '456669067890',
    language: 'en',
    timeZone: 'International Date Line West',
    website: 'https://keenthemes.com',
    emailSettings: {
      emailNotification: true,
      sendCopyToPersonalEmail: false,
      activityRelatesEmail: {
        youHaveNewNotifications: false,
        youAreSentADirectMessage: false,
        someoneAddsYouAsAsAConnection: true,
        uponNewOrder: false,
        newMembershipApproval: false,
        memberRegistration: true,
      },
      updatesFromKeenthemes: {
        newsAboutKeenthemesProductsAndFeatureUpdates: false,
        tipsOnGettingMoreOutOfKeen: false,
        thingsYouMissedSindeYouLastLoggedIntoKeen: true,
        newsAboutStartOnPartnerProductsAndOtherServices: true,
        tipsOnStartBusinessProducts: true,
      },
    },
    communication: {
      email: true,
      sms: true,
      phone: false,
    },
    address: {
      addressLine: 'L-12-20 Vertex, Cybersquare',
      city: 'San Francisco',
      state: 'California',
      postCode: '45000',
    },
    socialNetworks: {
      linkedIn: 'https://linkedin.com/admin',
      facebook: 'https://facebook.com/admin',
      twitter: 'https://twitter.com/admin',
      instagram: 'https://instagram.com/admin',
    },
  }}
  return user
}
