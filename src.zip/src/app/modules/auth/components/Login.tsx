/* eslint-disable jsx-a11y/anchor-is-valid */

//vinit
import React, {useState} from 'react'
import {useDispatch} from 'react-redux'
import * as Yup from 'yup'
import clsx from 'clsx'
import {Link, Redirect, useHistory} from 'react-router-dom'
import {useFormik} from 'formik'
import * as auth from '../redux/AuthRedux'
import {login} from '../redux/AuthCRUD'
import {toAbsoluteUrl} from '../../../../_metronic/helpers'


const loginSchema = Yup.object().shape({
  email: Yup.string()
    .email('Wrong email format')
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('Email is required'),
  password: Yup.string()
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('Password is required'),
})

// const initialValues = {
//   email: 'admin@demo.com',
//   password: 'demo',
// }
const initialValues = {
  email: '',
  password: '',
}
/*
  Formik+YUP+Typescript:
  https://jaredpalmer.com/formik/docs/tutorial#getfieldprops
  https://medium.com/@maurice.de.beijer/yup-validation-and-typescript-and-formik-6c342578a20e
*/

export function Login() {
  let history = useHistory();

  const [loading, setLoading] = useState(false)
  const dispatch = useDispatch()
  const formik = useFormik({
    initialValues,
    validationSchema: loginSchema,
    onSubmit: (values, {setStatus, setSubmitting}) => {
      setLoading(true)
      setTimeout( async () => {
        
        // login(values.email,values.password)
        //   .then(({data:{token}}) => {
        //      setLoading(false)
        //      dispatch(auth.actions.login(token))
        //      console.log("login Data",token)
        //   })
        //   .catch(() => {
        //     setLoading(false)
        //     setSubmitting(false)
        //     setStatus('The login detail is incorrect')
        //   })
       
          const user = {
            userEmail: values.email,
            userPassword: values.password,
           };
        await fetch("http://localhost:8082/api/auth/signin", {
          method: "post",
          headers: { "Content-Type": "application/json" },
          body:JSON.stringify(user) ,
          
        }).then((response) => response.json()) 
        .then((data)=>{
            // return response.json()
            //console.log("login success",data);
            if(data.token){
              window.location.reload();
              setLoading(false)
                alert(data.message)
             dispatch(auth.actions.login(`access-token-8f3ae836da744329a6f93bf20594b5cc`))
            }else{
              setLoading(false)
              // setStatus(data.message)
              setStatus("pls...enter valid Credentials")
            }
            //
            // <Redirect from='/auth'to="/dashboard"/>
           
            // {<Redirect to='/dashboard' />}
          //  alert("submitted Data");
          //return data
        });
        // .catch(data => {
        //   setLoading(false)
        //   setSubmitting(false)
        // setStatus('The login detail is incorrect')
        // })
        
      }, 1000)
    },
    // onReset:(values, {setStatus, setSubmitting}) => {
    //   values=initialValues;
    // }
  })

  return (
    <form
      className='form w-100'
      onSubmit={formik.handleSubmit}
      noValidate
      id='kt_login_signin_form'
    >
      {/* begin::Heading */}
      <div className='text-center mb-10'>
        <h1 className='text-dark mb-3'>Login</h1>
      </div>
      {/* begin::Heading */}
     
      {formik.status ? (
        <div className='mb-lg-15 alert alert-danger'>
          <div className='alert-text font-weight-bold'>{formik.status}</div>
        </div>
      ) : (
        <div className='mb-1 bg-light-info p-1 rounded'>
           {/* <div className='text-info'>
            Use account <strong>admin@demo.com</strong> and password <strong>demo</strong> to
            continue.
          </div>  */}
        </div>
      )}


      {/* begin::Form group */}
      <dl>
      <div className='fv-row mb-10'>
        <dt className=''> 
        <label className='form-label fs-6 fw-bolder text-dark'>Email</label>
        <input
          placeholder='Email'
          {...formik.getFieldProps('email')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            {'is-invalid': formik.touched.email && formik.errors.email},
            {
              'is-valid': formik.touched.email && !formik.errors.email,
            }
          )}
          type='email'
          name='email'
          autoComplete='off'
        />
        </dt>
         <dd className='position-absolute'>
         {formik.errors.email && (
          <div className='fv-plugins-message-container'>
            <span role='alert' className='text-danger'>{formik.errors.email}</span>
          </div>
        )}
         </dd>
      </div>
     {/* 2nd Field */}
      <div className='fv-row mb-10'>
        <dt className="">
        <div className='d-flex justify-content-between mt-n5'>
          <div className='d-flex flex-stack mb-2'>
            
            <label className='form-label fw-bolder text-dark fs-6 mb-0'>Password</label>
            {/* end::Label */}
         </div>
        </div>
        <input
        placeholder='password'
          type='password'
          autoComplete='off'
          {...formik.getFieldProps('password')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            {
              'is-invalid': formik.touched.password && formik.errors.password,
            },
            {
              'is-valid': formik.touched.password && !formik.errors.password,
            }
          )}
        />
        </dt>
         <dd className='position-absolute'>
      
        {formik.touched.password && formik.errors.password && (
          <div className='fv-plugins-message-container'>
            <div className='fv-help-block'>
              <span role='alert' className='text-danger'>{formik.errors.password}</span>
            </div>
          </div>
        )}
         </dd>
      </div>
      </dl>
      {/* end::Form group */}
      <div className='my-2'>
      <Link
              to='/auth/forgot-password'
              className='link-primary fs-6 fw-bolder'
              style={{marginLeft: '5px'}}
            >
              Forgot Password ?
            </Link>
      </div>

      {/* begin::Action */}
      <div className='text-center'>
        <div>
        <button
          type='submit'
          id='kt_sign_in_submit'
          className='btn btn-lg btn-primary w-100 mb-5'
          disabled={formik.isSubmitting || !formik.isValid}
        >
          {!loading && <span className='indicator-label'>Sign In</span>}
          {loading && (
            <span className='indicator-progress' style={{display: 'block'}}>
              Please wait...
              <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
            </span>
          )}
        </button>
        </div>
         {/* <div>
         <button
          type='reset'
          id='kt_sign_in_submit'
          className='btn btn-lg btn-info w-100 mb-5'
          disabled={formik.isSubmitting || !formik.isValid}
        >
         <span className='indicator-label'>Reset</span>
        </button>
         </div> */}
         <div>
         <div className='text-gray-400 fw-bold fs-4'>
          Didn't Have an Account?{' '}
          <Link to='/auth/registration' className='link-primary fw-bolder'>
            Sign Up
          </Link>
        </div>
         </div>
      
      </div>
      {/* end::Action */}
    </form>
  )
}