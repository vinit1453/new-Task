/* eslint-disable jsx-a11y/anchor-is-valid */
// Pradeep, 
import React, {useState} from 'react'
import {useDispatch} from 'react-redux'
import {Field, useFormik} from 'formik'
import * as Yup from 'yup'
import clsx from 'clsx'
import * as auth from '../redux/AuthRedux'
import {register} from '../redux/AuthCRUD'
import {Link,useHistory} from 'react-router-dom'
import {toAbsoluteUrl} from '../../../../_metronic/helpers'
import PhoneInput from 'react-phone-input-2'
import 'react-phone-input-2/lib/style.css'


const initialValues = {
  fname: '',
  cpassword: '',
  email: '',
  password: '',
  dob: '',
  acceptTerms: false,
  phNo:''
}

export function PhoneField(props:any){
  const [value,setValue]=useState("")
  return(
    <div className=''>
     <div className=''>
     <PhoneInput specialLabel={''} country={'us'}
      inputClass={clsx(
        'form-control form-control-lg form-control-solid w-100',
        // {
        //   'is-invalid': formik.touched.phNo && formik.errors.phNo,
        // },
        // {
        //   'is-valid': formik.touched.phNo && !formik.errors.phNo,
        // }
      )} 
      
      value={value}
      countryCodeEditable={false}
      enableSearch={true}
      // key={props.keys}
      inputProps={{
        name: "phNo",
        required: true
      }}  />
     </div>
    </div>
  )
}

const registrationSchema = Yup.object().shape({
  fname: Yup.string()
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('Name is required'),
  email: Yup.string()
    .email('Wrong email format')
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('Email is required'),
  phNo: Yup.string()
    .min(10, 'Minimum 10 symbols')
    .max(20, 'Maximum Limit Crossed')
    .required('Phone Number is required')
    .matches(/\+91\d{10}/,"Invalid Mobile Number"),
    
  dob: Yup.string()
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('DoB is required'),
  password: Yup.string()
    .min(3, 'Minimum 3 symbols')
    .max(50, 'Maximum 50 symbols')
    .required('Password is required'),
  cpassword: Yup.string()
    .required('Password confirmation is required')
    .when('password', {
      is: (val: string) => (val && val.length > 0 ? true : false),
      then: Yup.string().oneOf([Yup.ref('password')], "Password and Confirm Password didn't match"),
    }),
  acceptTerms: Yup.bool().required('You must accept the terms and conditions'),
})

export function Registration() {
  const [loading, setLoading] = useState(false)
  const dispatch = useDispatch()
  const history = useHistory();
  const formik = useFormik({
    initialValues,
    validationSchema: registrationSchema,
    
    onSubmit: (values, {setStatus, setSubmitting}) => {
      console.log("form Data",values)
      setLoading(true)
      setTimeout(() => {
        // register(values.email, values.fname, values.phNo, values.password, values.dob)
        //   .then((data) => {
        //     // setLoading(false)
        //     // dispatch(auth.actions.login(accessToken))
        //     console.log("data hit",data)
        //   })
        //   .catch(() => {
        //     setLoading(false)
        //     setSubmitting(false)
        //     setStatus('Registration process has broken')
        //   })
        // private String userName;
        // private String userEmail;
        // private String userPassword;
        // private Date userDateOfBirth;
        // private String userPhone;
        // fetch('http://localhost:8081/api/auth/signup')
        const user = {
          userName: values.fname,
          userEmail: values.email,
          userPassword: values.password,
          userDateOfBirth: values.dob,
          userPhone: values.phNo,
         };
        fetch("http://localhost:8082/api/auth/signup", {
          method: "post",
          headers: { "Content-Type": "application/json" },
          body:JSON.stringify(user) ,
          
        })
        .then(response => {
          // return response.json()
          //dispatch(auth.actions.login(accessToken))
          console.log("response",response.json())
          alert("Registerd Successfull,You may Login Now!");
           history.push('/');
        })
        .catch(data => {
          alert("error in APi")
          console.log("Api Data",user)
        })
        
      }, 1000)
    },
  })

  return (
    <form
      className='form w-100 fv-plugins-bootstrap5 fv-plugins-framework'
      noValidate
      id='kt_login_signup_form'
      onSubmit={formik.handleSubmit}
    >
      <div className="text-center">
          <h1 className='text-dark'>Sign Up</h1>
      </div>
     

      {formik.status && (
        <div className='alert alert-danger'>
          <div className='alert-text font-weight-bold'>{formik.status}</div>
        </div>
      )}

    <dl>
      {/* begin::Form group Firstname */}
      <div className='row fv-row '>   
        <div className='fv-row mb-6'>
         <dt>
         <label className='class="form-label fw-bolder text-dark'>Name</label>
          <input
            placeholder='Enter name'
            type='text'
            
            autoComplete='off'
            {...formik.getFieldProps('fname')}
            className={clsx(
              'form-control form-control-lg form-control-solid',
              {
                'is-invalid': formik.touched.fname && formik.errors.fname,
              },
              {
                'is-valid': formik.touched.fname && !formik.errors.fname,
              }
            )}
          />
         </dt>
         <dd className='position-absolute'>
         {formik.touched.fname && formik.errors.fname && (
            <div className='fv-plugins-message-container'>
              <div className='fv-help-block'>
                <span role='alert' className='text-danger'>{formik.errors.fname}</span>
              </div>
            </div>
          )}
         </dd>
        </div>
        
      </div>
      {/* end::Form group */}

      {/* begin::Form group Email */}
      <div className='fv-row mb-6'>
        <dt>
        <label className='form-label fw-bolder text-dark '>Email</label>
        <input
          placeholder='Email'
          type='email'
          autoComplete='off'
          {...formik.getFieldProps('email')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            {'is-invalid': formik.touched.email && formik.errors.email},
            {
              'is-valid': formik.touched.email && !formik.errors.email,
            }
          )}
        />
        </dt>
        <dd className='position-absolute'>
        {formik.touched.email && formik.errors.email && (
          <div className='fv-plugins-message-container'>
            <div className='fv-help-block'>
              <span role='alert' className='text-danger'>{formik.errors.email}</span>
            </div>
          </div>
        )}
        </dd>
      </div>
      {/* end::Form group */}

      {/* begin::Form group Password */}
      <div className=' fv-row mb-6' data-kt-password-meter='true'>
         <dt>
         <label className='form-label fw-bolder text-dark '>Password</label>
          <div className='position-relative'>
            <input
              type='password'
              placeholder='Password'
              autoComplete='off'
              {...formik.getFieldProps('password')}
              className={clsx(
                'form-control form-control-lg form-control-solid',
                {
                  'is-invalid': formik.touched.password && formik.errors.password,
                },
                {
                  'is-valid': formik.touched.password && !formik.errors.password,
                }
              )}
            />
            </div>
         </dt>
            <dd className='position-absolute'>
            {formik.touched.password && formik.errors.password && (
              <div className='fv-plugins-message-container'>
                <div className='fv-help-block'>
                  <span role='alert' className='text-danger'>{formik.errors.password}</span>
                </div>
              </div>
            )}
            </dd>
          </div>
        
      
      {/* end::Form group */}

      {/* begin::Form group Confirm password */}
      <div className='fv-row mb-6'>
        <dt>
        <label className='form-label fw-bolder text-dark '>Confirm Password</label>
        <input
          type='password'
          placeholder='Password confirmation'
          autoComplete='off'
          {...formik.getFieldProps('cpassword')}
          className={clsx(
            'form-control form-control-lg form-control-solid',
            {
              'is-invalid': formik.touched.cpassword && formik.errors.cpassword,
            },
            {
              'is-valid': formik.touched.cpassword && !formik.errors.cpassword,
            }
          )}
        />
        </dt>
        <dd className='position-absolute'>
        {formik.touched.cpassword && formik.errors.cpassword && (
          <div className='fv-plugins-message-container'>
            <div className='fv-help-block'>
              <span role='alert' className='text-danger'>{formik.errors.cpassword}</span>
            </div>
          </div>
        )}
        </dd>
      </div>
      {/* end::Form group */}

      {/* date of  birth start */}
      
      <div className='fv-row mb-6'>
         <dt>
         <label className='class="form-label fw-bolder text-dark '>Date of birth</label>
          <input
            placeholder='23/02/1999'
            type='date'
            autoComplete='off'
            {...formik.getFieldProps('dob')}
            className={clsx(
              'form-control form-control-lg form-control-solid',
              {
                'is-invalid': formik.touched.dob && formik.errors.dob,
              },
              {
                'is-valid': formik.touched.dob && !formik.errors.dob,
              }
            )}
          />
         </dt>
          <dd className='position-absolute'>
          {formik.touched.dob && formik.errors.dob && (
            <div className='fv-plugins-message-container'>
              <div className='fv-help-block'>
                <span role='alert' className='text-danger'>{formik.errors.dob}</span>
              </div>
            </div>
          )}
          </dd>
        </div>
      {/* date of  birth end here */}


      {/* phone no class group start here */}
      <div className='fv-row mb-6'>
         <dt>
         <label className='class="form-label fw-bolder text-dark '>Phone</label>
          {/* <div className=''> <PhoneField keys={{...formik.getFieldProps('phNo')}}/> </div> */}
           <input
            placeholder='Enter phone No'
            type='text'
            autoComplete='off'
            {...formik.getFieldProps('phNo')}
            className={clsx(
              'form-control form-control-lg form-control-solid',
              {
                'is-invalid': formik.touched.phNo && formik.errors.phNo,
              },
              {
                'is-valid': formik.touched.phNo && !formik.errors.phNo,
              }
            )}
          /> 
         </dt>
          <dd className='position-absolute'>
          {formik.touched.phNo && formik.errors.phNo && (
            <div className='fv-plugins-message-container'>
              <div className='fv-help-block'>
                <span role='alert' className='text-danger'>{formik.errors.phNo}</span>
              </div>
            </div>
          )}
          </dd>
        </div>
      {/* phone no class group end here */}

      {/* begin::Form group */}
      <div className='fv-row mb-6'>
        <div className='form-check form-check-custom form-check-solid'>
          {/* <input
            className='form-check-input'
            type='checkbox'
            id='kt_login_toc_agree'
            {...formik.getFieldProps('acceptTerms')}
          /> */}
          <label
            className='form-check-label fw-bold text-gray-700 '
            htmlFor='kt_login_toc_agree'
          >
            Already have an account ?{' '}
            <Link to='/auth/terms' className='ms-1 link-primary'>
              Sign In
            </Link>
            
          </label>
          {formik.touched.acceptTerms && formik.errors.acceptTerms && (
            <div className='fv-plugins-message-container'>
              <div className='fv-help-block'>
                <span role='alert' className='text-danger'>{formik.errors.acceptTerms}</span>
              </div>
            </div>
          )}
        </div>
      </div>
      {/* end::Form group */}


    </dl>

      {/* begin::Form group */}
      <div className='text-center'>
        <button
          type='submit'
          id='kt_sign_up_submit'
          className='btn btn-lg btn-primary w-100 mb-5'
          disabled={formik.isSubmitting || !formik.isValid }
        >
          {!loading && <span className='indicator-label'>Sign Up</span>}
          {loading && (
            <span className='indicator-progress' style={{display: 'block'}}>
              Please wait...{' '}
              <span className='spinner-border spinner-border-sm align-middle ms-2'></span>
            </span>
          )}
        </button>
        <Link to='/auth/login'>
          <button
            type='button'
            id='kt_login_signup_form_cancel_button'
            className='btn btn-lg btn-light-primary w-100 mb-5'
          >
            Cancel
          </button>
        </Link>
      </div>
      {/* end::Form group */}
    </form>
  )
}